const API_URL = process.env.REACT_APP_API_URL || "http://localhost:5000";

export async function createPipeline(payload) {
  const res = await fetch(`${API_URL}/api/v1/pipelines`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  return res.json();
}

export async function listPipelines() {
  const res = await fetch(`${API_URL}/api/v1/pipelines`);
  return res.json();
}

export async function getPipeline(id) {
  const res = await fetch(`${API_URL}/api/v1/pipelines/${id}`);
  return res.json();
}