import React, { useState, useEffect } from "react";
import { createPipeline, listPipelines, getPipeline } from "./services/api";

export default function Dashboard() {
  const [pipelines, setPipelines] = useState([]);
  const [form, setForm] = useState({
    name: "demo-pipeline",
    target_cloud: "aws",
    instance_type: "t3.medium",
    expose_publicly: false,
  });
  const [details, setDetails] = useState(null);

  useEffect(() => {
    refresh();
  }, []);

  async function refresh() {
    const data = await listPipelines();
    setPipelines(data);
  }

  async function trigger() {
    const result = await createPipeline(form);
    alert("Pipeline triggered: " + JSON.stringify(result));
    refresh();
  }

  async function showDetails(id) {
    const d = await getPipeline(id);
    setDetails(d);
  }

  return (
    <div>
      <h1>Multi-Cloud CI/CD Gateway</h1>

      <h3>Trigger Pipeline</h3>
      <input
        value={form.name}
        onChange={(e) => setForm({ ...form, name: e.target.value })}
      />
      <select
        value={form.target_cloud}
        onChange={(e) => setForm({ ...form, target_cloud: e.target.value })}
      >
        <option value="aws">AWS</option>
        <option value="azure">Azure</option>
        <option value="gcp">GCP</option>
      </select>
      <input
        value={form.instance_type}
        onChange={(e) => setForm({ ...form, instance_type: e.target.value })}
      />
      <label>
        <input
          type="checkbox"
          checked={form.expose_publicly}
          onChange={(e) =>
            setForm({ ...form, expose_publicly: e.target.checked })
          }
        />
        Expose publicly
      </label>
      <button onClick={trigger}>Trigger</button>

      <h3>Pipelines</h3>
      <table border="1" cellPadding="6">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Cloud</th>
            <th>Status</th>
            <th>Cost ($)</th>
            <th>Details</th>
          </tr>
        </thead>
        <tbody>
          {pipelines.map((p) => (
            <tr key={p.id}>
              <td>{p.id}</td>
              <td>{p.name}</td>
              <td>{p.target_cloud}</td>
              <td>{p.status}</td>
              <td>{p.cost_estimate}</td>
              <td>
                <button onClick={() => showDetails(p.id)}>View</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {details && (
        <div>
          <h3>Pipeline #{details.id}</h3>
          <pre>{JSON.stringify(details, null, 2)}</pre>
        </div>
      )}
    </div>
  );
}
