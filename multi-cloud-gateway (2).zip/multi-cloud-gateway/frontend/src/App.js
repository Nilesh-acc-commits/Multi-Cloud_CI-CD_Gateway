import React from "react";
import Dashboard from "./dashboard.js";

function App() {
  return <Dashboard />;
}

export default App;