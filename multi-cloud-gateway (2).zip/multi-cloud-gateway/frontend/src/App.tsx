import React, { useEffect, useState } from "react";
import { supabase } from "./lib/supabaseClient";
import { io } from "socket.io-client";
import { auth, provider } from "./lib/firebase";
import { signInWithPopup } from "firebase/auth";
import { motion } from "framer-motion";

const socket = io(import.meta.env.VITE_BACKEND_URL || "http://localhost:4000");

type Pipeline = {
  id: string; name: string; repository_url?: string; cloud_provider?: string; status: string;
};

export default function App() {
  const [pipelines, setPipelines] = useState<Pipeline[]>([]);
  const [name, setName] = useState("");
  const [repo, setRepo] = useState("");
  const [providerValue, setProviderValue] = useState("aws");

  async function loadPipelines() {
    const res = await fetch(`${import.meta.env.VITE_BACKEND_URL}/api/pipelines`);
    const data = await res.json();
    setPipelines(data);
  }

  useEffect(() => {
    loadPipelines();
    socket.on("pipeline_updated", (p: Pipeline) => {
      loadPipelines();
    });
    socket.on("pipeline_created", () => loadPipelines());
    socket.on("pipeline_running", () => loadPipelines());
    return () => { socket.off(); };
  }, []);

  async function createPipeline() {
    if (!name) return alert("name required");
    const res = await fetch(`${import.meta.env.VITE_BACKEND_URL}/api/create`, {
      method: "POST", headers: {"Content-Type":"application/json"},
      body: JSON.stringify({ name, repository_url: repo, cloud_provider: providerValue })
    });
    await res.json();
    setName(""); setRepo("");
    loadPipelines();
  }

  async function deploy(id: string) {
    await fetch(`${import.meta.env.VITE_BACKEND_URL}/api/deploy`, {
      method: "POST", headers: {"Content-Type":"application/json"},
      body: JSON.stringify({ pipeline_id: id })
    });
  }

  async function login() {
    try {
      await signInWithPopup(auth, provider);
      alert("Logged in");
    } catch (e) {
      alert("login failed");
    }
  }

  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <div className="max-w-3xl mx-auto">
        <div className="flex justify-between items-center mb-4">
          <h1 className="text-2xl font-bold">Multi-Cloud Gateway</h1>
          <button onClick={login} className="bg-blue-600 text-white px-3 py-1 rounded">Login</button>
        </div>

        <div className="mb-6">
          <input value={name} onChange={e=>setName(e.target.value)} placeholder="Name" className="border p-2 mr-2"/>
          <input value={repo} onChange={e=>setRepo(e.target.value)} placeholder="Repo URL" className="border p-2 mr-2"/>
          <select value={providerValue} onChange={e=>setProviderValue(e.target.value)} className="border p-2 mr-2">
            <option value="aws">AWS</option><option value="gcp">GCP</option><option value="azure">Azure</option>
          </select>
          <button onClick={createPipeline} className="bg-green-600 text-white px-3 py-1 rounded">Create</button>
        </div>

        <div className="space-y-3">
          {pipelines.map(p => (
            <motion.div key={p.id} initial={{opacity:0,y:10}} animate={{opacity:1,y:0}} className="p-4 bg-white rounded shadow flex justify-between items-center">
              <div>
                <div className="font-semibold">{p.name}</div>
                <div className="text-sm text-gray-500">{p.repository_url} • {p.cloud_provider}</div>
                <div className="text-xs">Status: <strong>{p.status}</strong></div>
              </div>
              <div>
                <button onClick={() => deploy(p.id)} className="bg-blue-600 text-white px-3 py-1 rounded">Deploy</button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
