// backend/costOptimizer.js
const pricing = { aws: { small: 20, medium: 50, large: 120 } };

module.exports.estimateCost = (cloud, instanceType) => {
  const size = instanceType.includes("small") ? "small" :
               instanceType.includes("large") ? "large" : "medium";
  return pricing[cloud][size] || 50;
};

module.exports.rightsize = (cloud, currentType, cpuUtil) => {
  if (cpuUtil < 30 && currentType.includes("large")) return "medium";
  if (cpuUtil < 30 && currentType.includes("medium")) return "small";
  if (cpuUtil > 80 && currentType.includes("small")) return "medium";
  return null;
};
