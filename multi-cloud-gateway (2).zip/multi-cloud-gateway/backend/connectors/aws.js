// backend/connectors/aws.js
module.exports.deploy = async (payload) => {
  return {
    status: "success",
    logs: `Mock AWS deployment for ${payload.instance_type} in ${payload.region}`,
    cost_estimate: 50.0 // mock monthly $
  };
};
