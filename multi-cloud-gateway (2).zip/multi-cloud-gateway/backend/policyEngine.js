// backend/policyEngine.js
module.exports.evaluate = (payload) => {
  const reasons = [];
  if (payload.expose_publicly) {
    reasons.push("Public exposure not allowed");
  }
  if (payload.instance_type === "m5.24xlarge") {
    reasons.push("Instance type too large");
  }
  return { allowed: reasons.length === 0, reasons };
};
