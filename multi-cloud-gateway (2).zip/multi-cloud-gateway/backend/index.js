require('dotenv').config();
const { evaluate } = require("./policyEngine");
const aws = require("./connectors/aws");
const azure = require("./connectors/azure");
const gcp = require("./connectors/gcp");
const { estimateCost } = require("./costOptimizer");

const express = require('express');
const cors = require('cors');
const axios = require('axios');
const http = require('http');
const { createClient } = require('@supabase/supabase-js');
const { Server } = require('socket.io');
const Redis = require('ioredis');
const admin = require('firebase-admin');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*' }
});

app.use(cors());
app.use(express.json());

// Firebase Admin SDK (for token verification)
if (process.env.FIREBASE_SERVICE_ACCOUNT_PATH) {
  const serviceAccount = require(process.env.FIREBASE_SERVICE_ACCOUNT_PATH);
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
  });
}

// Supabase client (service role key for admin access)
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

// Redis client
const redis = new Redis(process.env.REDIS_URL);

// Socket.IO connection
io.on('connection', (socket) => {
  console.log('Socket connected:', socket.id);
  socket.on('disconnect', () => {
    console.log('Socket disconnected:', socket.id);
  });
});

// Health check
app.get('/', (req, res) => {
  res.send('Multi-Cloud Gateway Backend is running');
});

// Get all pipelines (with Redis cache)
app.post("/api/v1/pipelines", async (req, res) => {
  const payload = req.body;

  // Policy enforcement
  const { allowed, reasons } = evaluate(payload);
  if (!allowed) return res.status(403).json({ allowed, reasons });

  // Choose connector
  let result;
  if (payload.target_cloud === "aws") result = await aws.deploy(payload);
  else if (payload.target_cloud === "azure") result = await azure.deploy(payload);
  else if (payload.target_cloud === "gcp") result = await gcp.deploy(payload);
  else result = { status: "failed", logs: "Unknown cloud" };

  // Cost estimate
  result.cost_estimate = estimateCost(payload.target_cloud, payload.instance_type);

  return res.json({ pipeline_id: Date.now(), ...result });
});

app.get('/api/pipelines', async (req, res) => {
  try {
    const cached = await redis.get('pipelines');
    if (cached) return res.json(JSON.parse(cached));

    const { data, error } = await supabase
      .from('pipelines')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) return res.status(500).json({ error: error.message });

    await redis.set('pipelines', JSON.stringify(data), 'EX', 30);
    res.json(data);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'internal' });
  }
});

// Create a new pipeline
app.post('/api/create', async (req, res) => {
  try {
    const { name, repository_url, cloud_provider } = req.body;
    if (!name) return res.status(400).json({ error: 'name required' });

    const { data, error } = await supabase
      .from('pipelines')
      .insert([{ name, repository_url, cloud_provider }])
      .select()
      .single();

    if (error) return res.status(500).json({ error: error.message });

    await redis.del('pipelines'); // clear cache
    io.emit('pipeline_created', data);

    res.json(data);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'internal' });
  }
});

// Deploy a pipeline (simulated, updates status and notifies Slack)
app.post('/api/deploy', async (req, res) => {
  try {
    const { pipeline_id } = req.body;
    if (!pipeline_id) return res.status(400).json({ error: 'pipeline_id required' });

    await supabase
      .from('pipelines')
      .update({ status: 'running', updated_at: new Date() })
      .eq('id', pipeline_id);

    io.emit('pipeline_running', { id: pipeline_id });

    setTimeout(async () => {
      try {
        const status = Math.random() > 0.2 ? 'success' : 'failed';

        await supabase
          .from('pipelines')
          .update({ status, updated_at: new Date() })
          .eq('id', pipeline_id);

        if (process.env.SLACK_WEBHOOK_URL) {
          await axios.post(process.env.SLACK_WEBHOOK_URL, {
            text: `Pipeline ${pipeline_id} finished with status: ${status.toUpperCase()}`
          });
        }

        if (process.env.PYTHON_ANALYTICS_URL) {
          try {
            const logs = await supabase
              .from('deploy_logs')
              .select('*')
              .limit(50)
              .order('timestamp', { ascending: false });

            await axios.post(process.env.PYTHON_ANALYTICS_URL, {
              deploy_logs: logs.data
            });
          } catch (e) {
            console.warn('Python analytics error:', e.message);
          }
        }

        const { data } = await supabase
          .from('pipelines')
          .select('*')
          .eq('id', pipeline_id)
          .single();

        io.emit('pipeline_updated', data);
        await redis.del('pipelines');
      } catch (e) {
        console.error('Deploy background error:', e.message);
      }
    }, 4000);

    res.json({ ok: true, message: 'deployment started' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'internal' });
  }
});

// Middleware: verify Firebase ID token (optional)
async function verifyToken(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Missing token' });

  try {
    const decoded = await admin.auth().verifyIdToken(token);
    req.user = decoded;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

// Start the server
const port = process.env.PORT || 4000;
server.listen(port, () => {
  console.log(`Backend listening on http://localhost:${port}`);
});
